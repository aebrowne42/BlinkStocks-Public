#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    /// <summary>
    /// VWAP Pro 2 - Volume Weighted Average Price indicator with standard deviation bands.
    /// Fixed version that correctly handles OnPriceChange and OnEachTick calculation modes.
    ///
    /// Features:
    /// - Session-based VWAP calculation with multiple anchor types
    /// - Configurable standard deviation bands (1, 2, 3 SD)
    /// - Multiple anchor types (Session, Daily, Weekly, Monthly, Custom)
    /// - Multiple typical price calculation methods (HLC3, OHLC4, HL2, Close)
    /// - Customizable colors and line styles
    ///
    /// Formula:
    /// VWAP = Σ(Typical Price × Volume) / Σ(Volume)
    /// Standard Deviation = √[Σ(TP² × V) / Σ(V) - VWAP²]
    /// </summary>
    public class VWAPPro2 : Indicator
    {
        #region Variables
        // Calculation state - accumulator values for COMPLETED bars only
        private double sumTPV;              // Σ(TP × Volume) for completed bars
        private double sumVolume;           // Σ(Volume) for completed bars
        private double sumTPVSquared;       // Σ(TP² × Volume) for completed bars

        // Current bar tracking - to handle tick-by-tick updates correctly
        private int lastBarProcessed;       // Track which bar we last processed
        private double currentBarTPV;       // Current bar's TP × V contribution
        private double currentBarVolume;    // Current bar's volume contribution
        private double currentBarTPVSq;     // Current bar's TP² × V contribution

        // Cached values for performance and zero-volume bar handling
        private double lastVWAP;
        private double lastStdDev;

        // Session tracking
        private DateTime sessionStartTime;
        private int anchorBar;
        #endregion

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                // Identity
                Description = @"Volume Weighted Average Price with Standard Deviation Bands (v2).
                               Fixed to correctly handle OnPriceChange and OnEachTick modes.
                               VWAP represents the average price weighted by volume, commonly used
                               by institutional traders as a benchmark for order execution quality.";
                Name = "VWAP Pro 2";

                // Calculation settings
                Calculate = Calculate.OnPriceChange;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                PaintPriceMarkers = true;
                ScaleJustification = ScaleJustification.Right;
                IsSuspendedWhileInactive = true;

                // Default parameters - VWAP Settings
                AnchorType = VWAPAnchorType2.Session;
                TypicalPriceType = VWAPPriceType2.HLC3;
                CustomAnchorTime = DateTime.Now.Date.AddHours(17); // Default 5:00 PM

                // Default parameters - Bands
                NumStdDev1 = 1.0;
                NumStdDev2 = 2.0;
                NumStdDev3 = 3.0;
                EnableBand1 = true;
                EnableBand2 = true;
                EnableBand3 = false;

                // Default parameters - Appearance
                VwapColor = Brushes.DodgerBlue;
                UpperBandColor = Brushes.Crimson;
                LowerBandColor = Brushes.LimeGreen;
                LineWidth = 2;
                BandLineWidth = 1;

                // Add plots - VWAP and 3 pairs of bands (upper/lower)
                AddPlot(new Stroke(Brushes.DodgerBlue, 2), PlotStyle.Line, "VWAP");
                AddPlot(new Stroke(Brushes.Crimson, 1), PlotStyle.Line, "Upper1");
                AddPlot(new Stroke(Brushes.LimeGreen, 1), PlotStyle.Line, "Lower1");
                AddPlot(new Stroke(Brushes.Crimson, 1), PlotStyle.Line, "Upper2");
                AddPlot(new Stroke(Brushes.LimeGreen, 1), PlotStyle.Line, "Lower2");
                AddPlot(new Stroke(Brushes.Crimson, 1), PlotStyle.Line, "Upper3");
                AddPlot(new Stroke(Brushes.LimeGreen, 1), PlotStyle.Line, "Lower3");
            }
            else if (State == State.DataLoaded)
            {
                // Initialize calculation state when data is ready
                ResetCalculations();
                lastBarProcessed = -1;

                // Update plot colors and widths from properties
                UpdatePlotAppearance();
            }
        }

        protected override void OnBarUpdate()
        {
            // Guard clause - need at least 1 bar for time comparison
            if (CurrentBar < 1)
            {
                // Initialize first bar
                double tp = GetTypicalPrice();
                double vol = Volume[0];

                if (vol > 0)
                {
                    currentBarTPV = tp * vol;
                    currentBarVolume = vol;
                    currentBarTPVSq = tp * tp * vol;
                    lastVWAP = tp;
                    lastStdDev = 0;
                }

                Values[0][0] = lastVWAP;
                SetBandValues(lastVWAP, 0);
                anchorBar = CurrentBar;
                lastBarProcessed = CurrentBar;
                return;
            }

            // Check if we've moved to a new bar
            if (CurrentBar != lastBarProcessed)
            {
                // Finalize the previous bar's contribution to the cumulative sums
                sumTPV += currentBarTPV;
                sumVolume += currentBarVolume;
                sumTPVSquared += currentBarTPVSq;

                // Reset current bar tracking
                currentBarTPV = 0;
                currentBarVolume = 0;
                currentBarTPVSq = 0;

                lastBarProcessed = CurrentBar;
            }

            // Check for session/anchor reset
            if (ShouldResetVWAP())
            {
                ResetCalculations();
                anchorBar = CurrentBar;
            }

            // Calculate typical price based on user preference
            double typicalPrice = GetTypicalPrice();
            double volume = Volume[0];

            // Handle zero or negative volume bars
            if (volume <= 0)
            {
                // Carry forward previous values
                Values[0][0] = lastVWAP;
                SetBandValues(lastVWAP, lastStdDev);
                return;
            }

            // Validate price data
            if (double.IsNaN(typicalPrice) || double.IsInfinity(typicalPrice))
            {
                Values[0][0] = lastVWAP;
                SetBandValues(lastVWAP, lastStdDev);
                return;
            }

            // Update the current bar's contribution (replace, not accumulate)
            currentBarTPV = typicalPrice * volume;
            currentBarVolume = volume;
            currentBarTPVSq = typicalPrice * typicalPrice * volume;

            // Calculate totals including current bar
            double totalTPV = sumTPV + currentBarTPV;
            double totalVolume = sumVolume + currentBarVolume;
            double totalTPVSq = sumTPVSquared + currentBarTPVSq;

            // Calculate VWAP
            double vwap = totalVolume > 0
                ? totalTPV / totalVolume
                : typicalPrice;

            // Calculate Standard Deviation (volume-weighted)
            // Formula: σ = √[Σ(TP² × V) / Σ(V) - VWAP²]
            double variance = (totalTPVSq / totalVolume) - (vwap * vwap);
            double stdDev = variance > 0 ? Math.Sqrt(variance) : 0;

            // Cache values for performance and zero-volume handling
            lastVWAP = vwap;
            lastStdDev = stdDev;

            // Set VWAP plot value
            Values[0][0] = vwap;

            // Set band values
            SetBandValues(vwap, stdDev);
        }

        #region Helper Methods

        /// <summary>
        /// Calculates the typical price based on the selected price type
        /// </summary>
        private double GetTypicalPrice()
        {
            switch (TypicalPriceType)
            {
                case VWAPPriceType2.HLC3:
                    return (High[0] + Low[0] + Close[0]) / 3.0;
                case VWAPPriceType2.OHLC4:
                    return (Open[0] + High[0] + Low[0] + Close[0]) / 4.0;
                case VWAPPriceType2.HL2:
                    return (High[0] + Low[0]) / 2.0;
                case VWAPPriceType2.Close:
                    return Close[0];
                default:
                    return (High[0] + Low[0] + Close[0]) / 3.0;
            }
        }

        /// <summary>
        /// Determines if VWAP should be reset based on anchor type
        /// </summary>
        private bool ShouldResetVWAP()
        {
            // Ensure we have enough bars to compare
            if (CurrentBar < 1)
                return false;

            switch (AnchorType)
            {
                case VWAPAnchorType2.Session:
                    return Bars.IsFirstBarOfSession;

                case VWAPAnchorType2.Daily:
                    return Time[0].Date != Time[1].Date;

                case VWAPAnchorType2.Weekly:
                    // Reset on Sunday (or first trading day of week)
                    return Time[0].DayOfWeek < Time[1].DayOfWeek ||
                           (Time[0].Date - Time[1].Date).Days >= 7;

                case VWAPAnchorType2.Monthly:
                    return Time[0].Month != Time[1].Month ||
                           Time[0].Year != Time[1].Year;

                case VWAPAnchorType2.Custom:
                    // Reset when crossing the custom anchor time (compare time-of-day only)
                    TimeSpan anchorTimeOfDay = CustomAnchorTime.TimeOfDay;
                    TimeSpan currentTimeOfDay = Time[0].TimeOfDay;
                    TimeSpan prevTimeOfDay = Time[1].TimeOfDay;

                    // Check if we crossed the anchor time
                    // This handles both same-day crossing and overnight crossing
                    bool crossedToday = currentTimeOfDay >= anchorTimeOfDay && prevTimeOfDay < anchorTimeOfDay;
                    bool crossedOvernight = currentTimeOfDay < prevTimeOfDay &&
                                           (currentTimeOfDay >= anchorTimeOfDay || prevTimeOfDay < anchorTimeOfDay);
                    bool newDay = Time[0].Date != Time[1].Date && currentTimeOfDay >= anchorTimeOfDay;

                    return crossedToday || crossedOvernight || newDay;

                default:
                    return Bars.IsFirstBarOfSession;
            }
        }

        /// <summary>
        /// Resets all calculation accumulators for a new VWAP period
        /// </summary>
        private void ResetCalculations()
        {
            sumTPV = 0;
            sumVolume = 0;
            sumTPVSquared = 0;
            currentBarTPV = 0;
            currentBarVolume = 0;
            currentBarTPVSq = 0;
            lastVWAP = 0;
            lastStdDev = 0;
            sessionStartTime = Time[0];
        }

        /// <summary>
        /// Sets the standard deviation band values
        /// </summary>
        private void SetBandValues(double vwap, double stdDev)
        {
            // Band 1
            if (EnableBand1)
            {
                Values[1][0] = vwap + (NumStdDev1 * stdDev);  // Upper1
                Values[2][0] = vwap - (NumStdDev1 * stdDev);  // Lower1
            }
            else
            {
                Values[1][0] = double.NaN;
                Values[2][0] = double.NaN;
            }

            // Band 2
            if (EnableBand2)
            {
                Values[3][0] = vwap + (NumStdDev2 * stdDev);  // Upper2
                Values[4][0] = vwap - (NumStdDev2 * stdDev);  // Lower2
            }
            else
            {
                Values[3][0] = double.NaN;
                Values[4][0] = double.NaN;
            }

            // Band 3
            if (EnableBand3)
            {
                Values[5][0] = vwap + (NumStdDev3 * stdDev);  // Upper3
                Values[6][0] = vwap - (NumStdDev3 * stdDev);  // Lower3
            }
            else
            {
                Values[5][0] = double.NaN;
                Values[6][0] = double.NaN;
            }
        }

        /// <summary>
        /// Updates plot colors and line widths from user properties
        /// </summary>
        private void UpdatePlotAppearance()
        {
            // Update VWAP plot
            Plots[0].Brush = VwapColor;
            Plots[0].Width = LineWidth;

            // Update upper band plots
            Plots[1].Brush = UpperBandColor;
            Plots[1].Width = BandLineWidth;
            Plots[3].Brush = UpperBandColor;
            Plots[3].Width = BandLineWidth;
            Plots[5].Brush = UpperBandColor;
            Plots[5].Width = BandLineWidth;

            // Update lower band plots
            Plots[2].Brush = LowerBandColor;
            Plots[2].Width = BandLineWidth;
            Plots[4].Brush = LowerBandColor;
            Plots[4].Width = BandLineWidth;
            Plots[6].Brush = LowerBandColor;
            Plots[6].Width = BandLineWidth;
        }

        #endregion

        #region Properties

        // === VWAP Configuration ===

        [NinjaScriptProperty]
        [Display(Name = "Anchor Type", Description = "When to reset VWAP calculation",
                 Order = 1, GroupName = "1. VWAP Settings")]
        public VWAPAnchorType2 AnchorType { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Typical Price", Description = "Price calculation method for VWAP",
                 Order = 2, GroupName = "1. VWAP Settings")]
        public VWAPPriceType2 TypicalPriceType { get; set; }

        [NinjaScriptProperty]
        [PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
        [Display(Name = "Custom Anchor Time", Description = "Time of day to reset VWAP (only used when Anchor Type = Custom)",
                 Order = 3, GroupName = "1. VWAP Settings")]
        public DateTime CustomAnchorTime { get; set; }

        // === Standard Deviation Bands ===

        [NinjaScriptProperty]
        [Display(Name = "Enable Band 1", Description = "Show first standard deviation band",
                 Order = 1, GroupName = "2. Bands")]
        public bool EnableBand1 { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 10)]
        [Display(Name = "Band 1 Std Dev", Description = "Standard deviation multiplier for band 1",
                 Order = 2, GroupName = "2. Bands")]
        public double NumStdDev1 { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Band 2", Description = "Show second standard deviation band",
                 Order = 3, GroupName = "2. Bands")]
        public bool EnableBand2 { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 10)]
        [Display(Name = "Band 2 Std Dev", Description = "Standard deviation multiplier for band 2",
                 Order = 4, GroupName = "2. Bands")]
        public double NumStdDev2 { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Band 3", Description = "Show third standard deviation band",
                 Order = 5, GroupName = "2. Bands")]
        public bool EnableBand3 { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 10)]
        [Display(Name = "Band 3 Std Dev", Description = "Standard deviation multiplier for band 3",
                 Order = 6, GroupName = "2. Bands")]
        public double NumStdDev3 { get; set; }

        // === Visual Settings ===

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "VWAP Color", Description = "Color of the main VWAP line",
                 Order = 1, GroupName = "3. Appearance")]
        public Brush VwapColor { get; set; }

        [Browsable(false)]
        public string VwapColorSerializable
        {
            get { return Serialize.BrushToString(VwapColor); }
            set { VwapColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Upper Band Color", Description = "Color of upper standard deviation bands",
                 Order = 2, GroupName = "3. Appearance")]
        public Brush UpperBandColor { get; set; }

        [Browsable(false)]
        public string UpperBandColorSerializable
        {
            get { return Serialize.BrushToString(UpperBandColor); }
            set { UpperBandColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Lower Band Color", Description = "Color of lower standard deviation bands",
                 Order = 3, GroupName = "3. Appearance")]
        public Brush LowerBandColor { get; set; }

        [Browsable(false)]
        public string LowerBandColorSerializable
        {
            get { return Serialize.BrushToString(LowerBandColor); }
            set { LowerBandColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(Name = "VWAP Line Width", Description = "Thickness of the main VWAP line",
                 Order = 4, GroupName = "3. Appearance")]
        public int LineWidth { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(Name = "Band Line Width", Description = "Thickness of the standard deviation band lines",
                 Order = 5, GroupName = "3. Appearance")]
        public int BandLineWidth { get; set; }

        // === Plot Accessors (for external access) ===

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> VWAP => Values[0];

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Upper1 => Values[1];

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Lower1 => Values[2];

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Upper2 => Values[3];

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Lower2 => Values[4];

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Upper3 => Values[5];

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Lower3 => Values[6];

        #endregion
    }

    #region Enums

    /// <summary>
    /// Defines when VWAP calculation should reset
    /// </summary>
    public enum VWAPAnchorType2
    {
        [Display(Name = "Session", Description = "Reset at the start of each trading session")]
        Session,

        [Display(Name = "Daily", Description = "Reset at the start of each calendar day")]
        Daily,

        [Display(Name = "Weekly", Description = "Reset at the start of each week (Sunday)")]
        Weekly,

        [Display(Name = "Monthly", Description = "Reset at the start of each month")]
        Monthly,

        [Display(Name = "Custom Time", Description = "Reset at a user-specified time each day")]
        Custom
    }

    /// <summary>
    /// Defines the price calculation method for VWAP
    /// </summary>
    public enum VWAPPriceType2
    {
        [Display(Name = "HLC/3 (Typical)", Description = "(High + Low + Close) / 3")]
        HLC3,

        [Display(Name = "OHLC/4", Description = "(Open + High + Low + Close) / 4")]
        OHLC4,

        [Display(Name = "HL/2 (Median)", Description = "(High + Low) / 2")]
        HL2,

        [Display(Name = "Close", Description = "Close price only")]
        Close
    }

    #endregion
}
