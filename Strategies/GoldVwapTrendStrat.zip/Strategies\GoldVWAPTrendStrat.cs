#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public class GoldVWAPTrendStrat : Strategy
    {
        private OrderFlowVWAP vwap;
        private SMA trendSMA;
        
        // Risk Management & Order Variables
        private int priorTradeCount = 0;
        private int sessionLosses = 0;
        private bool haltTrading = false;
        private double currentTargetPrice = 0;
        private Order entryOrder = null; // Tracks pending market order to prevent spam
        private DateTime lastResetDate = DateTime.MinValue;

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Trend SMA Period", Description="Moving Average period to determine the uptrend.", Order=1, GroupName="1. Parameters")]
        public int SmaPeriod { get; set; }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name="Front Run Ticks", Description="How many ticks above the 1st Band to trigger the Buy Market order.", Order=2, GroupName="1. Parameters")]
        public int FrontRunTicks { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, double.MaxValue)]
        [Display(Name="Stop Risk Multiplier", Description="Multiplier for the distance between the 1st Band and VWAP to calculate Stop Loss.", Order=3, GroupName="1. Parameters")]
        public double StopRiskMultiplier { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Max Session Losses", Description="Turns the strategy off for the day if this many losing trades occur.", Order=1, GroupName="2. Risk Management")]
        public int MaxSessionLosses { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description                                 = "Uptrend VWAP Strategy. Front runs the 1st Band with a Market Order and targets 2nd Band.";
                Name                                        = "GoldVWAPTrendStrat";
                
                // CRITICAL CHANGE: We must monitor live price changes to trigger the market order instantly
                Calculate                                   = Calculate.OnPriceChange; 
                
                EntriesPerDirection                         = 1;
                EntryHandling                               = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy                = true;
                ExitOnSessionCloseSeconds                   = 300;
                IsFillLimitOnTouch                          = false;
                MaximumBarsLookBack                         = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution                         = OrderFillResolution.Standard;
                Slippage                                    = 1;
                StartBehavior                               = StartBehavior.WaitUntilFlat;
                TimeInForce                                 = TimeInForce.Gtc;
                TraceOrders                                 = false;
                RealtimeErrorHandling                       = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling                          = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade                         = 75; 

                // Default Parameters
                SmaPeriod                                   = 50;
                FrontRunTicks                               = 2; // Default to triggering 2 ticks above the exact band
                StopRiskMultiplier                          = 0.5; 
                MaxSessionLosses                            = 3; 
            }
            else if (State == State.DataLoaded)
            {
                vwap = OrderFlowVWAP(VWAPResolution.Standard, Bars.TradingHours, VWAPStandardDeviations.Three, 1, 2, 3);
                trendSMA = SMA(SmaPeriod);
                
                AddChartIndicator(vwap);
                AddChartIndicator(trendSMA);

                priorTradeCount = 0;
                sessionLosses = 0;
                haltTrading = false;
                currentTargetPrice = 0;
                entryOrder = null;
                lastResetDate = DateTime.MinValue;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < BarsRequiredToTrade) return;

            // Place the time filter here:
            if (ToTime(Time[0]) >= 160000 && ToTime(Time[0]) <= 203500)
                return;
            
            // 1. RISK MANAGEMENT: Reset the circuit breaker automatically on a new calendar day
            if (Time[0].Date != lastResetDate)
            {
                lastResetDate = Time[0].Date;
                haltTrading = false;
                sessionLosses = 0;
                priorTradeCount = SystemPerformance.AllTrades.Count; 
            }

            // 2. RISK MANAGEMENT: Check if any new trades have closed
            if (SystemPerformance.AllTrades.Count > priorTradeCount)
            {
                for (int i = priorTradeCount; i < SystemPerformance.AllTrades.Count; i++)
                {
                    Trade closedTrade = SystemPerformance.AllTrades[i];
                    if (closedTrade.ProfitCurrency < 0)
                    {
                        sessionLosses++;
                    }
                }
                
                priorTradeCount = SystemPerformance.AllTrades.Count;

                if (sessionLosses >= MaxSessionLosses)
                {
                    haltTrading = true;
                    Print(Time[0] + " - CIRCUIT BREAKER: Max Session Losses (" + MaxSessionLosses + ") reached. Strategy turned off for the day.");
                }
            }

            if (haltTrading) return; 

            // 3. ENTRY LOGIC: Monitoring live price to fire Market Order on price change
            if (Position.MarketPosition == MarketPosition.Flat && entryOrder == null)
            {
                currentTargetPrice = 0; // Reset tracking variable

                // UPTREND FILTER: Checked live on price change using current bar values (Close[0] & trendSMA[0])
                if (CurrentBar > 0 && Close[0] > trendSMA[0])
                {
                    double bandPrice = vwap.StdDev1Upper[0];
                    double triggerPrice = bandPrice + (FrontRunTicks * TickSize);

                    // If the live price dips to our front-run trigger price, execute!
                    if (GetCurrentAsk() >= triggerPrice && GetCurrentAsk() <= (bandPrice + 1.0))
                    {
                        // Calculate Stop Loss distance based on the band itself, not the trigger price
                        double riskRange = bandPrice - vwap.VWAP[0];
                        double stopSizeTicks = Math.Max(1, Math.Round((riskRange * StopRiskMultiplier) / TickSize));

                        SetStopLoss("LongTrend", CalculationMode.Ticks, stopSizeTicks, false);

                        double longTarget = Instrument.MasterInstrument.RoundToTickSize(vwap.StdDev2Upper[0]);
                        SetProfitTarget("LongTrend", CalculationMode.Price, longTarget);
                        currentTargetPrice = longTarget;

                        // Submit the Market Order!
                        EnterLong("LongTrend");
                    }
                }
            }
            
            // 4. EXIT LOGIC: Update active Take Profit dynamically while in a position
            else if (Position.MarketPosition == MarketPosition.Long)
            {
                double updatedTarget = Instrument.MasterInstrument.RoundToTickSize(vwap.StdDev2Upper[0]);
                
                // ANTI-SPAM FILTER: Only send an order modification request to the broker if the target moved by at least 1 tick
                if (Math.Abs(updatedTarget - currentTargetPrice) >= TickSize)
                {
                    SetProfitTarget("LongTrend", CalculationMode.Price, updatedTarget);
                    currentTargetPrice = updatedTarget; // Update our tracker
                }
            }
        }

        // 5. ORDER TRACKER: Keeps track of pending market orders to prevent spamming the broker
        protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
        {
            if (order.Name == "LongTrend")
            {
                // Register the order when it's first submitted
                if (orderState == OrderState.Submitted || orderState == OrderState.Accepted || orderState == OrderState.Working)
                {
                    entryOrder = order;
                }
                else if (orderState == OrderState.Filled || orderState == OrderState.Cancelled || orderState == OrderState.Rejected)
                {
                    entryOrder = null;
                }
                
            }
        }
    }
}